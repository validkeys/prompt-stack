package main

import "embed"

//go:embed starter-prompts
var StarterPrompts embed.FS
