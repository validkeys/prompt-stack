package embed

import "embed"

//go:embed ../../starter-prompts
var StarterPrompts embed.FS
