package workspace

import (
	"errors"
	"testing"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/kyledavis/prompt-stack/internal/testutil"
)

// TestCharacterInputUpdatesContent verifies that typing characters updates the content
func TestCharacterInputUpdatesContent(t *testing.T) {
	model := New("")

	// Type text using helper
	model = testutil.TypeText(model, "hello").(Model)

	// Verify effect - content changed
	if model.GetContent() != "hello" {
		t.Errorf("expected 'hello', got '%s'", model.GetContent())
	}
}

// TestCharacterInputWithSpaces verifies that typing with spaces works correctly
func TestCharacterInputWithSpaces(t *testing.T) {
	model := New("")

	// Type text with spaces
	model = testutil.TypeText(model, "hello world").(Model)

	// Verify effect
	expected := "hello world"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestCharacterInputWithNewlines verifies that typing with newlines works correctly
func TestCharacterInputWithNewlines(t *testing.T) {
	model := New("")

	// Type text with newlines
	model = testutil.TypeText(model, "hello").(Model)
	model = testutil.PressKey(model, tea.KeyEnter).(Model)
	model = testutil.TypeText(model, "world").(Model)

	// Verify effect
	expected := "hello\nworld"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestBackspaceDeletesCharacter verifies that backspace deletes characters
func TestBackspaceDeletesCharacter(t *testing.T) {
	model := New("")

	// Type text
	model = testutil.TypeText(model, "hello").(Model)

	// Delete last character
	model = testutil.PressKey(model, tea.KeyBackspace).(Model)

	// Verify effect
	expected := "hell"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestBackspaceOnEmptyContent verifies backspace on empty content
func TestBackspaceOnEmptyContent(t *testing.T) {
	model := New("")

	// Try to delete on empty content
	model = testutil.PressKey(model, tea.KeyBackspace).(Model)

	// Verify effect - content should still be empty
	if model.GetContent() != "" {
		t.Errorf("expected empty content, got '%s'", model.GetContent())
	}
}

// TestBackspaceDeletesNewline verifies that backspace can delete newlines
func TestBackspaceDeletesNewline(t *testing.T) {
	model := New("")

	// Type text with newline
	model = testutil.TypeText(model, "hello").(Model)
	model = testutil.PressKey(model, tea.KeyEnter).(Model)
	model = testutil.TypeText(model, "world").(Model)

	// Delete newline
	model = testutil.PressKey(model, tea.KeyBackspace).(Model)

	// Verify effect - lines should be merged
	expected := "helloworld"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestInsertNewline verifies that Enter key inserts newlines
func TestInsertNewline(t *testing.T) {
	model := New("")

	// Type text and insert newline
	model = testutil.TypeText(model, "hello").(Model)
	model = testutil.PressKey(model, tea.KeyEnter).(Model)
	model = testutil.TypeText(model, "world").(Model)

	// Verify effect
	expected := "hello\nworld"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestInsertTab verifies that Tab key inserts spaces
func TestInsertTab(t *testing.T) {
	model := New("")

	// Type text and insert tab
	model = testutil.TypeText(model, "hello").(Model)
	model = testutil.PressKey(model, tea.KeyTab).(Model)
	model = testutil.TypeText(model, "world").(Model)

	// Verify effect - tab should insert 4 spaces
	expected := "hello    world"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestCursorPositionMovement verifies cursor position updates
func TestCursorPositionMovement(t *testing.T) {
	model := New("test")

	// Move cursor right
	model = testutil.PressKey(model, tea.KeyRight).(Model)

	// Verify effect - cursor position changed
	pos := model.GetCursorPosition()
	if pos != 1 {
		t.Errorf("expected cursor position 1, got %d", pos)
	}
}

// TestCursorPositionAtStart verifies cursor at start of content
func TestCursorPositionAtStart(t *testing.T) {
	model := New("test")

	// Cursor should be at position 0
	pos := model.GetCursorPosition()
	if pos != 0 {
		t.Errorf("expected cursor position 0, got %d", pos)
	}
}

// TestCursorPositionAtEnd verifies cursor at end of content
func TestCursorPositionAtEnd(t *testing.T) {
	model := New("test")

	// Move cursor to end
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)

	// Cursor should be at position 4
	pos := model.GetCursorPosition()
	if pos != 4 {
		t.Errorf("expected cursor position 4, got %d", pos)
	}
}

// TestCursorPositionWithNewlines verifies cursor position with multiple lines
func TestCursorPositionWithNewlines(t *testing.T) {
	model := New("")

	// Type text with newlines
	model = testutil.TypeText(model, "hello").(Model)
	model = testutil.PressKey(model, tea.KeyEnter).(Model)
	model = testutil.TypeText(model, "world").(Model)

	// Cursor should be at position 11 (5 + 1 + 5)
	pos := model.GetCursorPosition()
	if pos != 11 {
		t.Errorf("expected cursor position 11, got %d", pos)
	}
}

// TestCursorPositionMovementLeft verifies cursor movement left
func TestCursorPositionMovementLeft(t *testing.T) {
	model := New("test")

	// Move cursor right then left
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyLeft).(Model)

	// Cursor should be at position 1
	pos := model.GetCursorPosition()
	if pos != 1 {
		t.Errorf("expected cursor position 1, got %d", pos)
	}
}

// TestCursorPositionMovementUp verifies cursor movement up
func TestCursorPositionMovementUp(t *testing.T) {
	model := New("")

	// Type text with newlines
	model = testutil.TypeText(model, "hello").(Model)
	model = testutil.PressKey(model, tea.KeyEnter).(Model)
	model = testutil.TypeText(model, "world").(Model)

	// Move cursor up
	model = testutil.PressKey(model, tea.KeyUp).(Model)

	// Cursor should be at position 5 (end of first line)
	pos := model.GetCursorPosition()
	if pos != 5 {
		t.Errorf("expected cursor position 5, got %d", pos)
	}
}

// TestCursorPositionMovementDown verifies cursor movement down
func TestCursorPositionMovementDown(t *testing.T) {
	model := New("")

	// Type text with newlines
	model = testutil.TypeText(model, "hello").(Model)
	model = testutil.PressKey(model, tea.KeyEnter).(Model)
	model = testutil.TypeText(model, "world").(Model)

	// Move cursor up then down
	model = testutil.PressKey(model, tea.KeyUp).(Model)
	model = testutil.PressKey(model, tea.KeyDown).(Model)

	// Cursor should be at position 11 (end of second line)
	pos := model.GetCursorPosition()
	if pos != 11 {
		t.Errorf("expected cursor position 11, got %d", pos)
	}
}

// TestWindowSizeUpdate verifies that window size updates are handled
func TestWindowSizeUpdate(t *testing.T) {
	model := New("")

	// Set window size
	model = testutil.ResizeWindow(model, 80, 24).(Model)

	// Verify effect - size should be updated
	// We can't directly access width/height, but we can verify the model doesn't crash
	// and that subsequent operations work correctly
	model = testutil.TypeText(model, "test").(Model)

	if model.GetContent() != "test" {
		t.Errorf("expected 'test', got '%s'", model.GetContent())
	}
}

// TestTypingWorkflow verifies a complete typing workflow
func TestTypingWorkflow(t *testing.T) {
	model := New("")

	// Simulate typing workflow
	model = testutil.TypeText(model, "Hello").(Model)
	model = testutil.PressKey(model, tea.KeySpace).(Model)
	model = testutil.TypeText(model, "World").(Model)
	model = testutil.PressKey(model, tea.KeyEnter).(Model)
	model = testutil.TypeText(model, "!").(Model)

	// Verify final state
	expected := "Hello World\n!"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestEditWorkflow verifies an editing workflow
func TestEditWorkflow(t *testing.T) {
	model := New("Hello World")

	// Move to end, delete, type new text
	model = testutil.PressKey(model, tea.KeyRight).(Model) // Move right 11 times
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyRight).(Model)

	model = testutil.PressKey(model, tea.KeyBackspace).(Model) // Delete 'd'
	model = testutil.TypeText(model, "k").(Model)              // Type 'k'

	// Verify
	expected := "Hello Work"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestEmptyContentCursorMovement verifies cursor movement on empty content
func TestEmptyContentCursorMovement(t *testing.T) {
	model := New("")

	// Try to move cursor on empty content
	model = testutil.PressKey(model, tea.KeyRight).(Model)
	model = testutil.PressKey(model, tea.KeyLeft).(Model)
	model = testutil.PressKey(model, tea.KeyUp).(Model)
	model = testutil.PressKey(model, tea.KeyDown).(Model)

	// Cursor should stay at position 0
	pos := model.GetCursorPosition()
	if pos != 0 {
		t.Errorf("expected cursor position 0, got %d", pos)
	}
}

// TestUnicodeCharacters verifies that unicode characters are handled correctly
func TestUnicodeCharacters(t *testing.T) {
	model := New("")

	// Type unicode characters
	model = testutil.TypeText(model, "Hello 世界 🌍").(Model)

	// Verify effect
	expected := "Hello 世界 🌍"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestVeryLongLine verifies that very long lines are handled correctly
func TestVeryLongLine(t *testing.T) {
	model := New("")

	// Type a very long line
	longText := "a"
	for i := 0; i < 100; i++ {
		longText += "a"
	}
	model = testutil.TypeText(model, longText).(Model)

	// Verify effect
	if len(model.GetContent()) != 101 {
		t.Errorf("expected length 101, got %d", len(model.GetContent()))
	}
}

// TestMultipleNewlines verifies multiple newlines
func TestMultipleNewlines(t *testing.T) {
	model := New("")

	// Type text with multiple newlines
	model = testutil.TypeText(model, "line1").(Model)
	model = testutil.PressKey(model, tea.KeyEnter).(Model)
	model = testutil.TypeText(model, "line2").(Model)
	model = testutil.PressKey(model, tea.KeyEnter).(Model)
	model = testutil.TypeText(model, "line3").(Model)

	// Verify effect
	expected := "line1\nline2\nline3"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestSetContent verifies that SetContent updates the content
func TestSetContent(t *testing.T) {
	model := New("")

	// Set content
	model.SetContent("new content")

	// Verify effect
	if model.GetContent() != "new content" {
		t.Errorf("expected 'new content', got '%s'", model.GetContent())
	}
}

// TestInsertContent verifies that InsertContent inserts content at a position
func TestInsertContent(t *testing.T) {
	model := New("hello world")

	// Insert content at position 5
	model.InsertContent(5, " beautiful")

	// Verify effect
	expected := "hello beautiful world"
	if model.GetContent() != expected {
		t.Errorf("expected '%s', got '%s'", expected, model.GetContent())
	}
}

// TestMarkDirty verifies that MarkDirty marks the model as dirty
func TestMarkDirty(t *testing.T) {
	model := New("")

	// Mark as dirty
	model.MarkDirty()

	// We can't directly access isDirty, but we can verify the model doesn't crash
	// and that subsequent operations work correctly
	model = testutil.TypeText(model, "test").(Model)

	if model.GetContent() != "test" {
		t.Errorf("expected 'test', got '%s'", model.GetContent())
	}
}

// TestSetStatus verifies that SetStatus updates the status bar message
func TestSetStatus(t *testing.T) {
	model := New("")

	// Set status
	model.SetStatus("test status")

	// We can't directly access statusBar.message, but we can verify the model doesn't crash
	// and that subsequent operations work correctly
	model = testutil.TypeText(model, "test").(Model)

	if model.GetContent() != "test" {
		t.Errorf("expected 'test', got '%s'", model.GetContent())
	}
}

// TestSetSize verifies that SetSize updates the workspace size
func TestSetSize(t *testing.T) {
	model := New("")

	// Set size
	model.SetSize(80, 24)

	// We can't directly access width/height, but we can verify the model doesn't crash
	// and that subsequent operations work correctly
	model = testutil.TypeText(model, "test").(Model)

	if model.GetContent() != "test" {
		t.Errorf("expected 'test', got '%s'", model.GetContent())
	}
}

// TestSetReadOnly verifies that SetReadOnly updates the read-only state
func TestSetReadOnly(t *testing.T) {
	model := New("")

	// Set read-only
	model.SetReadOnly(true)

	// Verify effect
	if !model.IsReadOnly() {
		t.Errorf("expected read-only to be true")
	}

	// Set read-only to false
	model.SetReadOnly(false)

	// Verify effect
	if model.IsReadOnly() {
		t.Errorf("expected read-only to be false")
	}
}

// TestSetAIApplying verifies that SetAIApplying updates the AI applying state
func TestSetAIApplying(t *testing.T) {
	model := New("")

	// Set AI applying
	model.SetAIApplying(true)

	// Verify effect
	if !model.IsAIApplying() {
		t.Errorf("expected AI applying to be true")
	}

	// Verify that read-only is also set
	if !model.IsReadOnly() {
		t.Errorf("expected read-only to be true when AI is applying")
	}

	// Set AI applying to false
	model.SetAIApplying(false)

	// Verify effect
	if model.IsAIApplying() {
		t.Errorf("expected AI applying to be false")
	}
}

// TestUndoRedoWorkflow verifies undo/redo functionality
func TestUndoRedoWorkflow(t *testing.T) {
	model := New("")

	// Type text
	model = testutil.TypeText(model, "hello").(Model)

	// Undo
	model = testutil.PressKey(model, tea.KeyCtrlZ).(Model)

	// Verify effect - content should be empty
	if model.GetContent() != "" {
		t.Errorf("expected empty content after undo, got '%s'", model.GetContent())
	}

	// Redo
	model = testutil.PressKey(model, tea.KeyCtrlY).(Model)

	// Verify effect - content should be restored
	if model.GetContent() != "hello" {
		t.Errorf("expected 'hello' after redo, got '%s'", model.GetContent())
	}
}

// TestMultipleUndo verifies multiple undo operations
func TestMultipleUndo(t *testing.T) {
	model := New("")

	// Type multiple words
	model = testutil.TypeText(model, "hello").(Model)
	model = testutil.PressKey(model, tea.KeySpace).(Model)
	model = testutil.TypeText(model, "world").(Model)

	// Undo twice
	model = testutil.PressKey(model, tea.KeyCtrlZ).(Model)
	model = testutil.PressKey(model, tea.KeyCtrlZ).(Model)

	// Verify effect - content should be empty
	if model.GetContent() != "" {
		t.Errorf("expected empty content after multiple undos, got '%s'", model.GetContent())
	}
}

// TestUndoAfterBackspace verifies undo after backspace
func TestUndoAfterBackspace(t *testing.T) {
	model := New("")

	// Type text
	model = testutil.TypeText(model, "hello").(Model)

	// Delete character
	model = testutil.PressKey(model, tea.KeyBackspace).(Model)

	// Verify effect
	if model.GetContent() != "hell" {
		t.Errorf("expected 'hell', got '%s'", model.GetContent())
	}

	// Undo
	model = testutil.PressKey(model, tea.KeyCtrlZ).(Model)

	// Verify effect - content should be restored
	if model.GetContent() != "hello" {
		t.Errorf("expected 'hello' after undo, got '%s'", model.GetContent())
	}
}

// TestUndoAfterNewline verifies undo after newline
func TestUndoAfterNewline(t *testing.T) {
	model := New("")

	// Type text
	model = testutil.TypeText(model, "hello").(Model)

	// Insert newline
	model = testutil.PressKey(model, tea.KeyEnter).(Model)

	// Verify effect
	if model.GetContent() != "hello\n" {
		t.Errorf("expected 'hello\\n', got '%s'", model.GetContent())
	}

	// Undo
	model = testutil.PressKey(model, tea.KeyCtrlZ).(Model)

	// Verify effect - content should be restored
	if model.GetContent() != "hello" {
		t.Errorf("expected 'hello' after undo, got '%s'", model.GetContent())
	}
}

// TestMessageCoverage verifies that all message types are handled correctly
func TestMessageCoverage(t *testing.T) {
	tests := []struct {
		name    string
		msg     tea.Msg
		wantCmd bool
	}{
		// Window size messages
		{"window resize", tea.WindowSizeMsg{Width: 80, Height: 24}, false},

		// Key messages - navigation
		{"key up", tea.KeyMsg{Type: tea.KeyUp}, false},
		{"key down", tea.KeyMsg{Type: tea.KeyDown}, false},
		{"key left", tea.KeyMsg{Type: tea.KeyLeft}, false},
		{"key right", tea.KeyMsg{Type: tea.KeyRight}, false},

		// Key messages - editing
		{"key backspace", tea.KeyMsg{Type: tea.KeyBackspace}, false},
		{"key enter", tea.KeyMsg{Type: tea.KeyEnter}, false},
		{"key tab", tea.KeyMsg{Type: tea.KeyTab}, false},
		{"key shift+tab", tea.KeyMsg{Type: tea.KeyShiftTab}, false},
		{"key space", tea.KeyMsg{Type: tea.KeySpace}, false},
		{"key runes", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}}, false},

		// Key messages - special
		{"key ctrl+c", tea.KeyMsg{Type: tea.KeyCtrlC}, true},
		{"key ctrl+z", tea.KeyMsg{Type: tea.KeyCtrlZ}, false},
		{"key ctrl+y", tea.KeyMsg{Type: tea.KeyCtrlY}, false},

		// Custom messages - auto-save
		{"auto save", autoSaveMsg{}, true},
		{"save success", saveSuccessMsg{}, true},
		{"save error", saveErrorMsg{err: errors.New("test error")}, false},
		{"clear save status", clearSaveStatusMsg{}, false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			model := New("test content")
			_, cmd := model.Update(tt.msg)

			if tt.wantCmd && cmd == nil {
				t.Errorf("expected command for %s", tt.name)
			}
			if !tt.wantCmd && cmd != nil {
				t.Errorf("expected no command for %s, got %v", tt.name, cmd)
			}
		})
	}
}

// TestKeyMessagesInReadOnlyMode verifies that editing is blocked in read-only mode
func TestKeyMessagesInReadOnlyMode(t *testing.T) {
	tests := []struct {
		name string
		key  tea.KeyType
	}{
		{"backspace blocked", tea.KeyBackspace},
		{"enter blocked", tea.KeyEnter},
		{"tab blocked", tea.KeyTab},
		{"space blocked", tea.KeySpace},
		{"runes blocked", tea.KeyRunes},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			model := New("test content")
			model = model.SetReadOnly(true)

			// Get original content
			originalContent := model.GetContent()

			// Try to edit
			_, cmd := model.Update(tea.KeyMsg{Type: tt.key})

			// Verify no command returned
			if cmd != nil {
				t.Errorf("expected no command in read-only mode, got %v", cmd)
			}

			// Verify content unchanged
			if model.GetContent() != originalContent {
				t.Errorf("content should not change in read-only mode")
			}
		})
	}
}

// TestNavigationInReadOnlyMode verifies that navigation works in read-only mode
func TestNavigationInReadOnlyMode(t *testing.T) {
	tests := []struct {
		name string
		key  tea.KeyType
	}{
		{"up allowed", tea.KeyUp},
		{"down allowed", tea.KeyDown},
		{"left allowed", tea.KeyLeft},
		{"right allowed", tea.KeyRight},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			model := New("test content")
			model = model.SetReadOnly(true)

			// Navigate
			_, cmd := model.Update(tea.KeyMsg{Type: tt.key})

			// Verify no command returned
			if cmd != nil {
				t.Errorf("expected no command for navigation, got %v", cmd)
			}

			// Cursor may have moved (that's OK for navigation)
			// Just verify no crash
		})
	}
}

// TestAutoSaveWorkflow verifies the auto-save message flow
func TestAutoSaveWorkflow(t *testing.T) {
	model := New("test content")

	// Trigger auto-save
	_, cmd := model.Update(autoSaveMsg{})

	// Verify command is returned
	if cmd == nil {
		t.Fatal("expected command from autoSaveMsg")
	}

	// Execute command - should return saveSuccessMsg or saveErrorMsg
	msg := cmd()

	switch msg.(type) {
	case saveSuccessMsg:
		// Expected
	case saveErrorMsg:
		// Also acceptable (file save might fail)
	default:
		t.Errorf("expected saveSuccessMsg or saveErrorMsg, got %v", msg)
	}
}

// TestSaveSuccessFlow verifies save success message handling
func TestSaveSuccessFlow(t *testing.T) {
	model := New("test content")
	model = model.MarkDirty()

	// Verify dirty before save
	if !model.isDirty {
		t.Error("model should be dirty before save")
	}

	// Send save success message
	newModel, cmd := model.Update(saveSuccessMsg{})

	// Verify command is returned (tick to clear status)
	if cmd == nil {
		t.Fatal("expected command from saveSuccessMsg")
	}

	// Type assert to access fields
	workspaceModel := newModel.(Model)

	// Verify model is no longer dirty
	if workspaceModel.isDirty {
		t.Error("model should not be dirty after save success")
	}

	// Verify save status is set
	if workspaceModel.saveStatus != "saved" {
		t.Errorf("expected saveStatus 'saved', got '%s'", workspaceModel.saveStatus)
	}
}

// TestSaveErrorFlow verifies save error message handling
func TestSaveErrorFlow(t *testing.T) {
	model := New("test content")

	// Send save error message
	testErr := errors.New("test save error")
	newModel, cmd := model.Update(saveErrorMsg{err: testErr})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command from saveErrorMsg, got %v", cmd)
	}

	// Type assert to access fields
	workspaceModel := newModel.(Model)

	// Verify save status is set to error
	if workspaceModel.saveStatus != "error" {
		t.Errorf("expected saveStatus 'error', got '%s'", workspaceModel.saveStatus)
	}

	// Verify error message is set in status bar
	if workspaceModel.statusBar.message == "" {
		t.Error("expected error message in status bar")
	}
}

// TestClearSaveStatusFlow verifies clear save status message handling
func TestClearSaveStatusFlow(t *testing.T) {
	model := New("test content")
	model.saveStatus = "saved"
	model.statusBar.message = "Saved successfully"

	// Send clear save status message
	newModel, cmd := model.Update(clearSaveStatusMsg{})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command from clearSaveStatusMsg, got %v", cmd)
	}

	// Type assert to access fields
	workspaceModel := newModel.(Model)

	// Verify save status is cleared
	if workspaceModel.saveStatus != "" {
		t.Errorf("expected saveStatus '', got '%s'", workspaceModel.saveStatus)
	}

	// Verify status bar message is cleared
	if workspaceModel.statusBar.message != "" {
		t.Errorf("expected status bar message '', got '%s'", workspaceModel.statusBar.message)
	}
}

// TestCtrlCWithUnsavedChanges verifies Ctrl+C behavior with unsaved changes
func TestCtrlCWithUnsavedChanges(t *testing.T) {
	model := New("test content")
	model = model.MarkDirty()

	// Send Ctrl+C
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyCtrlC})

	// Verify quit command is returned
	if cmd == nil {
		t.Fatal("expected quit command from Ctrl+C")
	}

	// Verify it's a command (tea.Quit is a special command)
	// Just verify command was returned, don't try to compare to tea.Quit
}

// TestCtrlCWithoutUnsavedChanges verifies Ctrl+C behavior without unsaved changes
func TestCtrlCWithoutUnsavedChanges(t *testing.T) {
	model := New("test content")
	// Don't mark as dirty

	// Send Ctrl+C
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyCtrlC})

	// Verify quit command is returned
	if cmd == nil {
		t.Fatal("expected quit command from Ctrl+C")
	}

	// Verify it's a command (tea.Quit is a special command)
	// Just verify command was returned, don't try to compare to tea.Quit
}

// TestUndoRedoMessages verifies undo/redo key messages
func TestUndoRedoMessages(t *testing.T) {
	model := New("test content")

	// Type some text to create undo history
	model = testutil.TypeText(model, "hello").(Model)

	// Test Ctrl+Z (undo)
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyCtrlZ})
	if cmd != nil {
		t.Errorf("expected no command from Ctrl+Z, got %v", cmd)
	}

	// Test Ctrl+Y (redo)
	_, cmd = model.Update(tea.KeyMsg{Type: tea.KeyCtrlY})
	if cmd != nil {
		t.Errorf("expected no command from Ctrl+Y, got %v", cmd)
	}
}

// TestTabWithPlaceholder verifies Tab key behavior with placeholders
func TestTabWithPlaceholder(t *testing.T) {
	// Create content with placeholder
	content := "Hello {{name}}, welcome!"
	model := New(content)

	// Send Tab key
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyTab})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command from Tab, got %v", cmd)
	}

	// Verify active placeholder is set (if placeholder found)
	// This depends on placeholder parsing, so we just verify no crash
}

// TestShiftTabWithPlaceholder verifies Shift+Tab key behavior with placeholders
func TestShiftTabWithPlaceholder(t *testing.T) {
	// Create content with placeholder
	content := "Hello {{name}}, welcome!"
	model := New(content)

	// Send Shift+Tab key
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyShiftTab})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command from Shift+Tab, got %v", cmd)
	}

	// Verify no crash
}

// TestRunesWithPlaceholderEdit verifies typing in placeholder edit mode
func TestRunesWithPlaceholderEdit(t *testing.T) {
	// Create content with placeholder
	content := "Hello {{name}}, welcome!"
	model := New(content)

	// Enter placeholder edit mode by pressing 'i'
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'i'}})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command from 'i' key, got %v", cmd)
	}

	// Type some characters
	_, cmd = model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'T', 'e', 's', 't'}})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command from typing in edit mode, got %v", cmd)
	}
}

// TestEscapeInPlaceholderEdit verifies Escape key exits placeholder edit mode
func TestEscapeInPlaceholderEdit(t *testing.T) {
	// Create content with placeholder
	content := "Hello {{name}}, welcome!"
	model := New(content)

	// Enter placeholder edit mode
	_, _ = model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'i'}})

	// Send Escape key
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyEsc})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command from Escape, got %v", cmd)
	}

	// Verify placeholder edit mode is exited
	if model.placeholderEditMode {
		t.Error("placeholderEditMode should be false after Escape")
	}
}

// TestEnterInPlaceholderEdit verifies Enter key saves and exits placeholder edit mode
func TestEnterInPlaceholderEdit(t *testing.T) {
	// Create content with placeholder
	content := "Hello {{name}}, welcome!"
	model := New(content)

	// Enter placeholder edit mode
	_, _ = model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'i'}})

	// Send Enter key
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyEnter})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command from Enter, got %v", cmd)
	}

	// Verify placeholder edit mode is exited
	if model.placeholderEditMode {
		t.Error("placeholderEditMode should be false after Enter")
	}
}

// TestBackspaceInPlaceholderEdit verifies Backspace in placeholder edit mode
func TestBackspaceInPlaceholderEdit(t *testing.T) {
	// Create content with placeholder
	content := "Hello {{name}}, welcome!"
	model := New(content)

	// Enter placeholder edit mode and type some text
	newModel, _ := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'i'}})
	model = newModel.(Model)
	newModel, _ = model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'T', 'e', 's', 't'}})
	model = newModel.(Model)

	// Send Backspace key
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyBackspace})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command from Backspace, got %v", cmd)
	}

	// Verify edit value is shortened (if placeholder edit mode was entered)
	// Note: This test may not actually enter placeholder edit mode if no placeholder is found
	// Just verify no crash
	workspaceModel := newModel.(Model)
	_ = workspaceModel.placeholderEditValue
}
