package suggestions

import (
	"testing"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/kyledavis/prompt-stack/internal/ai"
)

// TestNewModel verifies that NewModel creates a properly initialized model
func TestNewModel(t *testing.T) {
	model := NewModel()

	// Verify initial state
	if len(model.suggestions) != 0 {
		t.Errorf("expected 0 suggestions, got %d", len(model.suggestions))
	}
	if model.selectedIndex != 0 {
		t.Errorf("expected selectedIndex 0, got %d", model.selectedIndex)
	}
	if model.width != 80 {
		t.Errorf("expected width 80, got %d", model.width)
	}
	if model.height != 20 {
		t.Errorf("expected height 20, got %d", model.height)
	}
}

// TestSetSuggestions verifies that SetSuggestions updates the model
func TestSetSuggestions(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1", Description: "first suggestion"},
		{Title: "suggestion 2", Description: "second suggestion"},
	}

	model.SetSuggestions(suggestions)

	// Verify suggestions are set
	if len(model.suggestions) != 2 {
		t.Errorf("expected 2 suggestions, got %d", len(model.suggestions))
	}

	// Verify selection is reset to first item
	if model.list.Index() != 0 {
		t.Errorf("expected selection at index 0, got %d", model.list.Index())
	}
}

// TestSetSuggestionsEmpty verifies that empty suggestions are handled
func TestSetSuggestionsEmpty(t *testing.T) {
	model := NewModel()

	model.SetSuggestions([]ai.Suggestion{})

	// Verify no suggestions
	if len(model.suggestions) != 0 {
		t.Errorf("expected 0 suggestions, got %d", len(model.suggestions))
	}
}

// TestGetSelectedSuggestion verifies that GetSelectedSuggestion returns the correct suggestion
func TestGetSelectedSuggestion(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1"},
		{Title: "suggestion 2"},
		{Title: "suggestion 3"},
	}

	model.SetSuggestions(suggestions)

	// Select second suggestion
	model.list.Select(1)

	selected := model.GetSelectedSuggestion()

	if selected == nil {
		t.Fatal("expected selected suggestion, got nil")
	}

	if selected.Title != "suggestion 2" {
		t.Errorf("expected 'suggestion 2', got '%s'", selected.Title)
	}
}

// TestGetSelectedSuggestionEmpty verifies that GetSelectedSuggestion returns nil when empty
func TestGetSelectedSuggestionEmpty(t *testing.T) {
	model := NewModel()

	selected := model.GetSelectedSuggestion()

	if selected != nil {
		t.Errorf("expected nil, got %v", selected)
	}
}

// TestGetSelectedSuggestionInvalidIndex verifies that GetSelectedSuggestion handles invalid index
func TestGetSelectedSuggestionInvalidIndex(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1"},
	}

	model.SetSuggestions(suggestions)

	// Set invalid index
	model.list.Select(10)

	selected := model.GetSelectedSuggestion()

	if selected != nil {
		t.Errorf("expected nil for invalid index, got %v", selected)
	}
}

// TestGetSuggestions verifies that GetSuggestions returns all suggestions
func TestGetSuggestions(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1"},
		{Title: "suggestion 2"},
	}

	model.SetSuggestions(suggestions)

	retrieved := model.GetSuggestions()

	if len(retrieved) != 2 {
		t.Errorf("expected 2 suggestions, got %d", len(retrieved))
	}

	if retrieved[0].Title != "suggestion 1" {
		t.Errorf("expected 'suggestion 1', got '%s'", retrieved[0].Title)
	}
}

// TestSetOnApply verifies that SetOnApply sets the callback
func TestSetOnApply(t *testing.T) {
	model := NewModel()

	called := false
	model.SetOnApply(func(suggestion *ai.Suggestion) tea.Cmd {
		called = true
		return nil
	})

	if model.onApply == nil {
		t.Error("expected onApply callback to be set")
	}

	// Test callback execution
	model.onApply(&ai.Suggestion{Title: "test"})

	if !called {
		t.Error("expected onApply callback to be called")
	}
}

// TestSetOnDismiss verifies that SetOnDismiss sets the callback
func TestSetOnDismiss(t *testing.T) {
	model := NewModel()

	called := false
	model.SetOnDismiss(func(suggestion *ai.Suggestion) tea.Cmd {
		called = true
		return nil
	})

	if model.onDismiss == nil {
		t.Error("expected onDismiss callback to be set")
	}

	// Test callback execution
	model.onDismiss(&ai.Suggestion{Title: "test"})

	if !called {
		t.Error("expected onDismiss callback to be called")
	}
}

// TestSetSize verifies that SetSize updates the model dimensions
func TestSetSize(t *testing.T) {
	model := NewModel()

	model.SetSize(100, 30)

	// Verify dimensions are updated
	if model.width != 100 {
		t.Errorf("expected width 100, got %d", model.width)
	}
	if model.height != 30 {
		t.Errorf("expected height 30, got %d", model.height)
	}

	// Verify list size is updated
	if model.list.Width() != 100 {
		t.Errorf("expected list width 100, got %d", model.list.Width())
	}
	if model.list.Height() != 28 {
		t.Errorf("expected list height 28, got %d", model.list.Height())
	}

	// Verify viewport size is updated
	if model.viewport.Width != 100 {
		t.Errorf("expected viewport width 100, got %d", model.viewport.Width)
	}
	if model.viewport.Height != 28 {
		t.Errorf("expected viewport height 28, got %d", model.viewport.Height)
	}
}

// TestUpdateKeyMessages verifies that key messages are handled correctly
func TestUpdateKeyMessages(t *testing.T) {
	model := NewModel()

	// Create test suggestions with Pending status and proposed changes
	suggestions := []ai.Suggestion{
		{
			Title:           "suggestion 1",
			Status:          ai.SuggestionStatusPending,
			ProposedChanges: []ai.Edit{{Line: 1, Column: 1, OldContent: "old", NewContent: "new", Length: 3}},
		},
		{
			Title:           "suggestion 2",
			Status:          ai.SuggestionStatusPending,
			ProposedChanges: []ai.Edit{{Line: 1, Column: 1, OldContent: "old", NewContent: "new", Length: 3}},
		},
	}

	model.SetSuggestions(suggestions)

	// Set callbacks for apply/dismiss
	model.SetOnApply(func(suggestion *ai.Suggestion) tea.Cmd {
		return func() tea.Msg { return tea.Msg("applied") }
	})
	model.SetOnDismiss(func(suggestion *ai.Suggestion) tea.Cmd {
		return func() tea.Msg { return tea.Msg("dismissed") }
	})

	tests := []struct {
		name    string
		msg     tea.Msg
		wantCmd bool
	}{
		{"apply with 'a'", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}}, true},
		{"apply with 'A'", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'A'}}, true},
		{"dismiss with 'd'", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'d'}}, true},
		{"dismiss with 'D'", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'D'}}, true},
		{"navigate up", tea.KeyMsg{Type: tea.KeyUp}, false},
		{"navigate down", tea.KeyMsg{Type: tea.KeyDown}, false},
		{"navigate with 'k'", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'k'}}, false},
		{"navigate with 'j'", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'j'}}, false},
		{"go to home", tea.KeyMsg{Type: tea.KeyHome}, false},
		{"go to end", tea.KeyMsg{Type: tea.KeyEnd}, false},
		{"page up", tea.KeyMsg{Type: tea.KeyPgUp}, false},
		{"page down", tea.KeyMsg{Type: tea.KeyPgDown}, false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, cmd := model.Update(tt.msg)

			if tt.wantCmd && cmd == nil {
				t.Errorf("expected command for %s", tt.name)
			}
			if !tt.wantCmd && cmd != nil {
				t.Errorf("expected no command for %s, got %v", tt.name, cmd)
			}
		})
	}
}

// TestUpdateWindowSize verifies that window resize is handled
func TestUpdateWindowSize(t *testing.T) {
	model := NewModel()

	newModel, cmd := model.Update(tea.WindowSizeMsg{Width: 120, Height: 40})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected no command for WindowSizeMsg, got %v", cmd)
	}

	// Verify dimensions are updated
	if newModel.width != 120 {
		t.Errorf("expected width 120, got %d", newModel.width)
	}
	if newModel.height != 40 {
		t.Errorf("expected height 40, got %d", newModel.height)
	}
}

// TestApplySuggestion verifies that applying a suggestion calls the callback
func TestApplySuggestion(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1", Status: ai.SuggestionStatusPending},
	}

	model.SetSuggestions(suggestions)

	called := false
	model.SetOnApply(func(suggestion *ai.Suggestion) tea.Cmd {
		called = true
		if suggestion.Title != "suggestion 1" {
			t.Errorf("expected 'suggestion 1', got '%s'", suggestion.Title)
		}
		return nil
	})

	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}})

	if !called {
		t.Error("expected onApply callback to be called")
	}

	if cmd == nil {
		t.Error("expected command from onApply callback")
	}
}

// TestDismissSuggestion verifies that dismissing a suggestion calls the callback
func TestDismissSuggestion(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1"},
	}

	model.SetSuggestions(suggestions)

	called := false
	model.SetOnDismiss(func(suggestion *ai.Suggestion) tea.Cmd {
		called = true
		if suggestion.Title != "suggestion 1" {
			t.Errorf("expected 'suggestion 1', got '%s'", suggestion.Title)
		}
		return nil
	})

	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'d'}})

	if !called {
		t.Error("expected onDismiss callback to be called")
	}

	if cmd == nil {
		t.Error("expected command from onDismiss callback")
	}
}

// TestApplyNonApplicableSuggestion verifies that non-applicable suggestions are not applied
func TestApplyNonApplicableSuggestion(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1", Status: ai.SuggestionStatusApplied},
	}

	model.SetSuggestions(suggestions)

	called := false
	model.SetOnApply(func(suggestion *ai.Suggestion) tea.Cmd {
		called = true
		return nil
	})

	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}})

	if called {
		t.Error("expected onApply callback not to be called for non-applicable suggestion")
	}

	if cmd != nil {
		t.Error("expected no command for non-applicable suggestion")
	}
}

// TestNavigation verifies that navigation keys work correctly
func TestNavigation(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1"},
		{Title: "suggestion 2"},
		{Title: "suggestion 3"},
	}

	model.SetSuggestions(suggestions)

	// Test down navigation
	model, _ = model.Update(tea.KeyMsg{Type: tea.KeyDown})
	if model.list.Index() != 1 {
		t.Errorf("expected index 1 after down, got %d", model.list.Index())
	}

	// Test up navigation
	model, _ = model.Update(tea.KeyMsg{Type: tea.KeyUp})
	if model.list.Index() != 0 {
		t.Errorf("expected index 0 after up, got %d", model.list.Index())
	}

	// Test home
	model, _ = model.Update(tea.KeyMsg{Type: tea.KeyHome})
	if model.list.Index() != 0 {
		t.Errorf("expected index 0 after home, got %d", model.list.Index())
	}

	// Test end
	model, _ = model.Update(tea.KeyMsg{Type: tea.KeyEnd})
	if model.list.Index() != 2 {
		t.Errorf("expected index 2 after end, got %d", model.list.Index())
	}
}

// TestViewEmpty verifies that View renders empty state correctly
func TestViewEmpty(t *testing.T) {
	model := NewModel()

	view := model.View()

	if view == "" {
		t.Error("expected view to render empty state")
	}

	// Should contain empty state text
	if len(view) == 0 {
		t.Error("expected non-empty view")
	}
}

// TestViewWithSuggestions verifies that View renders suggestions correctly
func TestViewWithSuggestions(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{
			Title:       "suggestion 1",
			Description: "first suggestion",
			Type:        ai.SuggestionTypeFormatting,
			Status:      ai.SuggestionStatusPending,
		},
	}

	model.SetSuggestions(suggestions)
	model.SetSize(80, 20)

	view := model.View()

	if view == "" {
		t.Error("expected view to render suggestions")
	}

	// Should contain suggestion title
	if len(view) == 0 {
		t.Error("expected non-empty view")
	}
}

// TestSuggestionItemFilterValue verifies that FilterValue returns the title
func TestSuggestionItemFilterValue(t *testing.T) {
	suggestion := &ai.Suggestion{Title: "test suggestion"}
	item := suggestionItem{suggestion: suggestion, index: 0}

	filterValue := item.FilterValue()

	if filterValue != "test suggestion" {
		t.Errorf("expected 'test suggestion', got '%s'", filterValue)
	}
}

// TestSuggestionDelegateHeight verifies that delegate returns correct height
func TestSuggestionDelegateHeight(t *testing.T) {
	delegate := suggestionDelegate{}

	height := delegate.Height()

	if height != 4 {
		t.Errorf("expected height 4, got %d", height)
	}
}

// TestSuggestionDelegateSpacing verifies that delegate returns correct spacing
func TestSuggestionDelegateSpacing(t *testing.T) {
	delegate := suggestionDelegate{}

	spacing := delegate.Spacing()

	if spacing != 0 {
		t.Errorf("expected spacing 0, got %d", spacing)
	}
}

// TestSuggestionDelegateUpdate verifies that delegate Update returns nil
func TestSuggestionDelegateUpdate(t *testing.T) {
	delegate := suggestionDelegate{}

	cmd := delegate.Update(tea.KeyMsg{}, nil)

	if cmd != nil {
		t.Errorf("expected nil command from delegate Update, got %v", cmd)
	}
}

// TestPluralize verifies that pluralize returns correct form
func TestPluralize(t *testing.T) {
	tests := []struct {
		count int
		want  string
	}{
		{0, "s"},
		{1, ""},
		{2, "s"},
		{10, "s"},
	}

	for _, tt := range tests {
		t.Run(tt.want, func(t *testing.T) {
			result := pluralize(tt.count)
			if result != tt.want {
				t.Errorf("expected '%s', got '%s'", tt.want, result)
			}
		})
	}
}

// TestMessageCoverage verifies that all message types are handled
func TestMessageCoverage(t *testing.T) {
	model := NewModel()

	// Create test suggestions with Pending status and proposed changes
	suggestions := []ai.Suggestion{
		{
			Title:           "suggestion 1",
			Status:          ai.SuggestionStatusPending,
			ProposedChanges: []ai.Edit{{Line: 1, Column: 1, OldContent: "old", NewContent: "new", Length: 3}},
		},
	}

	model.SetSuggestions(suggestions)

	// Set callbacks for apply/dismiss
	model.SetOnApply(func(suggestion *ai.Suggestion) tea.Cmd {
		return func() tea.Msg { return tea.Msg("applied") }
	})
	model.SetOnDismiss(func(suggestion *ai.Suggestion) tea.Cmd {
		return func() tea.Msg { return tea.Msg("dismissed") }
	})

	tests := []struct {
		name    string
		msg     tea.Msg
		wantCmd bool
	}{
		{"window resize", tea.WindowSizeMsg{Width: 80, Height: 24}, false},
		{"key up", tea.KeyMsg{Type: tea.KeyUp}, false},
		{"key down", tea.KeyMsg{Type: tea.KeyDown}, false},
		{"key home", tea.KeyMsg{Type: tea.KeyHome}, false},
		{"key end", tea.KeyMsg{Type: tea.KeyEnd}, false},
		{"key pgup", tea.KeyMsg{Type: tea.KeyPgUp}, false},
		{"key pgdown", tea.KeyMsg{Type: tea.KeyPgDown}, false},
		{"key apply", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}}, true},
		{"key dismiss", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'d'}}, true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, cmd := model.Update(tt.msg)

			if tt.wantCmd && cmd == nil {
				t.Errorf("expected command for %s", tt.name)
			}
			if !tt.wantCmd && cmd != nil {
				t.Errorf("expected no command for %s, got %v", tt.name, cmd)
			}
		})
	}
}

// TestNavigationBoundaries verifies that navigation respects boundaries
func TestNavigationBoundaries(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1"},
		{Title: "suggestion 2"},
	}

	model.SetSuggestions(suggestions)

	// Try to navigate up from first item
	model, _ = model.Update(tea.KeyMsg{Type: tea.KeyUp})
	if model.list.Index() != 0 {
		t.Errorf("expected index 0 (boundary), got %d", model.list.Index())
	}

	// Navigate to last item
	model, _ = model.Update(tea.KeyMsg{Type: tea.KeyDown})
	if model.list.Index() != 1 {
		t.Errorf("expected index 1, got %d", model.list.Index())
	}

	// Try to navigate down from last item
	model, _ = model.Update(tea.KeyMsg{Type: tea.KeyDown})
	if model.list.Index() != 1 {
		t.Errorf("expected index 1 (boundary), got %d", model.list.Index())
	}
}

// TestApplyWithoutCallback verifies that apply works without callback
func TestApplyWithoutCallback(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1", Status: ai.SuggestionStatusPending},
	}

	model.SetSuggestions(suggestions)

	// Don't set onApply callback
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}})

	// Should not crash, just return nil
	if cmd != nil {
		t.Error("expected nil command when no callback is set")
	}
}

// TestDismissWithoutCallback verifies that dismiss works without callback
func TestDismissWithoutCallback(t *testing.T) {
	model := NewModel()

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1"},
	}

	model.SetSuggestions(suggestions)

	// Don't set onDismiss callback
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'d'}})

	// Should not crash, just return nil
	if cmd != nil {
		t.Error("expected nil command when no callback is set")
	}
}
