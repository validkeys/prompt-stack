package app

import (
	"errors"
	"testing"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/kyledavis/prompt-stack/internal/ai"
	"github.com/kyledavis/prompt-stack/internal/commands"
	"github.com/kyledavis/prompt-stack/internal/history"
	"github.com/kyledavis/prompt-stack/internal/library"
	"github.com/kyledavis/prompt-stack/internal/prompt"
	"github.com/kyledavis/prompt-stack/ui/browser"
	"github.com/kyledavis/prompt-stack/ui/diffviewer"
	"github.com/kyledavis/prompt-stack/ui/palette"
	"go.uber.org/zap"
)

// TestQuitReturnsCommand verifies that Ctrl+C returns tea.Quit command
func TestQuitReturnsCommand(t *testing.T) {
	model := New(".")

	// Send quit message
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyCtrlC})

	// Verify command is returned
	if cmd == nil {
		t.Fatal("expected command, got nil")
	}

	// Verify it's a quit command by executing it
	msg := cmd()
	// tea.Quit is a special message - just verify command was returned
	if msg == nil {
		t.Errorf("expected tea.Quit message, got nil")
	}
}

// TestTriggerAISuggestionsReturnsCommand verifies that triggering AI suggestions returns a command
func TestTriggerAISuggestionsReturnsCommand(t *testing.T) {
	// Create model with dependencies
	lib := &library.Library{Prompts: make(map[string]*prompt.Prompt)}
	registry := commands.NewRegistry()

	// Create temporary database for testing
	tmpDir := t.TempDir()
	dbPath := tmpDir + "/test.db"
	db, err := history.Initialize(dbPath, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create database: %v", err)
	}
	defer db.Close()

	storage, err := history.NewStorage(tmpDir, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create storage: %v", err)
	}

	historyMgr := history.NewManager(db, storage, zap.NewNop())

	aiClient, err := ai.NewClient(ai.Config{
		APIKey: "test-key",
		Model:  "claude-3-sonnet-20240229",
		Logger: zap.NewNop(),
	})
	if err != nil {
		t.Fatalf("failed to create AI client: %v", err)
	}

	contextSelector := ai.NewContextSelector()

	model := NewWithDependencies(".", lib, registry, historyMgr, false, aiClient, contextSelector)

	// Trigger AI suggestions
	_, cmd := model.Update(TriggerAISuggestionsMsg{})

	// Verify command is returned
	if cmd == nil {
		t.Fatal("expected command, got nil")
	}

	// Verify command type by executing it
	msg := cmd()
	if _, ok := msg.(AISuggestionsGeneratedMsg); ok {
		// This is expected - the command should eventually return AISuggestionsGeneratedMsg
		// or AISuggestionsErrorMsg
	} else if _, ok := msg.(AISuggestionsErrorMsg); ok {
		// Also acceptable - error case
	} else {
		t.Errorf("expected AI suggestions message, got %v", msg)
	}
}

// TestPaletteExecuteSuccessReturnsCommand verifies that successful palette execution returns command
func TestPaletteExecuteSuccessReturnsCommand(t *testing.T) {
	model := New(".")

	// Send palette execute success message for AI suggestions
	_, cmd := model.Update(palette.ExecuteSuccessMsg{
		CommandID: "ai-suggestions",
	})

	// Verify command is returned
	if cmd == nil {
		t.Fatal("expected command, got nil")
	}

	// Verify command type by executing it
	msg := cmd()
	if _, ok := msg.(TriggerAISuggestionsMsg); !ok {
		t.Errorf("expected TriggerAISuggestionsMsg, got %v", msg)
	}
}

// TestDiffViewerCallbacksReturnCommands verifies that diff viewer callbacks return commands
func TestDiffViewerCallbacksReturnCommands(t *testing.T) {
	model := New(".")

	// Create a simple diff
	diff := &ai.UnifiedDiff{
		Header: "--- original\n+++ new",
		Hunks:  []ai.DiffHunk{},
	}

	// Show diff viewer
	_, cmd := model.Update(diffviewer.ShowDiffMsg{
		Diff:     diff,
		Original: "original content",
		Edits:    []ai.Edit{{Line: 1, Column: 1, OldContent: "old", NewContent: "new", Length: 3}},
	})

	// Command should be nil for showing diff (no async operation)
	if cmd != nil {
		t.Errorf("expected nil command for ShowDiffMsg, got %v", cmd)
	}

	// Test accept diff callback
	_, cmd = model.Update(diffviewer.AcceptDiffMsg{})
	if cmd != nil {
		t.Errorf("expected nil command for AcceptDiffMsg, got %v", cmd)
	}

	// Test reject diff callback
	_, cmd = model.Update(diffviewer.RejectDiffMsg{})
	if cmd != nil {
		t.Errorf("expected nil command for RejectDiffMsg, got %v", cmd)
	}
}

// TestKeyBindingsReturnCommands verifies that key bindings return appropriate commands
func TestKeyBindingsReturnCommands(t *testing.T) {
	tests := []struct {
		name    string
		key     tea.KeyType
		wantCmd bool
	}{
		{"ctrl+c returns command", tea.KeyCtrlC, true},
		{"ctrl+p returns no command", tea.KeyCtrlP, false},
		{"ctrl+b returns no command", tea.KeyCtrlB, false},
		{"ctrl+h returns no command", tea.KeyCtrlH, false},
		{"enter returns no command", tea.KeyEnter, false},
		{"escape returns no command", tea.KeyEsc, false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			model := New(".")
			_, cmd := model.Update(tea.KeyMsg{Type: tt.key})

			if tt.wantCmd && cmd == nil {
				t.Errorf("expected command for %s", tt.name)
			}
			if !tt.wantCmd && cmd != nil {
				t.Errorf("expected no command for %s, got %v", tt.name, cmd)
			}
		})
	}
}

// TestWindowSizeReturnsNoCommand verifies that window resize returns no command
func TestWindowSizeReturnsNoCommand(t *testing.T) {
	model := New(".")

	// Send window size message
	_, cmd := model.Update(tea.WindowSizeMsg{Width: 100, Height: 30})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected nil command for WindowSizeMsg, got %v", cmd)
	}
}

// TestBrowserMessagesReturnNoCommand verifies that browser messages return no command
func TestBrowserMessagesReturnNoCommand(t *testing.T) {
	lib := &library.Library{Prompts: make(map[string]*prompt.Prompt)}
	registry := commands.NewRegistry()
	model := NewWithDependencies(".", lib, registry, nil, false, nil, nil)

	// Test insert prompt message
	_, cmd := model.Update(browser.InsertPromptMsg{
		FilePath:   "test.md",
		InsertMode: browser.InsertAtCursor,
	})

	if cmd != nil {
		t.Errorf("expected nil command for InsertPromptMsg, got %v", cmd)
	}

	// Test validation error message
	_, cmd = model.Update(browser.ValidationErrorMsg{
		FilePath: "test.md",
		Errors:   []prompt.ValidationError{{Message: "test error"}},
	})

	if cmd != nil {
		t.Errorf("expected nil command for ValidationErrorMsg, got %v", cmd)
	}
}

// TestHistoryMessagesReturnNoCommand verifies that history messages return no command
func TestHistoryMessagesReturnNoCommand(t *testing.T) {
	tmpDir := t.TempDir()
	dbPath := tmpDir + "/test.db"
	db, err := history.Initialize(dbPath, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create database: %v", err)
	}
	defer db.Close()

	storage, err := history.NewStorage(tmpDir, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create storage: %v", err)
	}

	historyMgr := history.NewManager(db, storage, zap.NewNop())
	lib := &library.Library{Prompts: make(map[string]*prompt.Prompt)}
	registry := commands.NewRegistry()
	model := NewWithDependencies(".", lib, registry, historyMgr, false, nil, nil)

	// Test load history message
	_, cmd := model.Update(LoadHistoryMsg{FilePath: "test.md"})

	if cmd != nil {
		t.Errorf("expected nil command for LoadHistoryMsg, got %v", cmd)
	}

	// Test delete history message
	_, cmd = model.Update(DeleteHistoryMsg{FilePath: "test.md"})

	if cmd != nil {
		t.Errorf("expected nil command for DeleteHistoryMsg, got %v", cmd)
	}
}

// TestPaletteExecuteErrorReturnsNoCommand verifies that palette error returns no command
func TestPaletteExecuteErrorReturnsNoCommand(t *testing.T) {
	model := New(".")

	// Send palette execute error message
	_, cmd := model.Update(palette.ExecuteErrorMsg{
		CommandID: "test-command",
		Error:     errors.New("test error"),
	})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected nil command for ExecuteErrorMsg, got %v", cmd)
	}
}

// TestAISuggestionsGeneratedReturnsNoCommand verifies that AI suggestions generated returns no command
func TestAISuggestionsGeneratedReturnsNoCommand(t *testing.T) {
	model := New(".")

	// Send AI suggestions generated message
	_, cmd := model.Update(AISuggestionsGeneratedMsg{
		Suggestions: []ai.Suggestion{{Title: "test"}},
	})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected nil command for AISuggestionsGeneratedMsg, got %v", cmd)
	}
}

// TestAISuggestionsErrorReturnsNoCommand verifies that AI error returns no command
func TestAISuggestionsErrorReturnsNoCommand(t *testing.T) {
	model := New(".")

	// Send AI error message
	_, cmd := model.Update(AISuggestionsErrorMsg{
		Error: errors.New("test error"),
	})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected nil command for AISuggestionsErrorMsg, got %v", cmd)
	}
}

// TestGenerateAISuggestionsReturnsCommand verifies that generateAISuggestions returns a command
func TestGenerateAISuggestionsReturnsCommand(t *testing.T) {
	lib := &library.Library{Prompts: make(map[string]*prompt.Prompt)}
	registry := commands.NewRegistry()

	tmpDir := t.TempDir()
	dbPath := tmpDir + "/test.db"
	db, err := history.Initialize(dbPath, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create database: %v", err)
	}
	defer db.Close()

	storage, err := history.NewStorage(tmpDir, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create storage: %v", err)
	}

	historyMgr := history.NewManager(db, storage, zap.NewNop())

	aiClient, err := ai.NewClient(ai.Config{
		APIKey: "test-key",
		Model:  "claude-3-sonnet-20240229",
		Logger: zap.NewNop(),
	})
	if err != nil {
		t.Fatalf("failed to create AI client: %v", err)
	}

	contextSelector := ai.NewContextSelector()

	model := NewWithDependencies(".", lib, registry, historyMgr, false, aiClient, contextSelector)

	// Call generateAISuggestions directly
	cmd := model.generateAISuggestions("test composition")

	// Verify command is returned
	if cmd == nil {
		t.Fatal("expected command from generateAISuggestions, got nil")
	}

	// Verify command type by executing it
	msg := cmd()
	// Should return either AISuggestionsGeneratedMsg or AISuggestionsErrorMsg
	if _, ok := msg.(AISuggestionsGeneratedMsg); !ok {
		if _, ok := msg.(AISuggestionsErrorMsg); !ok {
			t.Errorf("expected AI suggestions message, got %v", msg)
		}
	}
}

// TestSetSuggestionsReturnsModel verifies that SetSuggestions returns updated model
func TestSetSuggestionsReturnsModel(t *testing.T) {
	model := New(".")

	suggestions := []ai.Suggestion{
		{Title: "suggestion 1"},
		{Title: "suggestion 2"},
	}

	newModel := model.SetSuggestions(suggestions)

	// Verify model is updated
	if len(newModel.GetSuggestions()) != 2 {
		t.Errorf("expected 2 suggestions, got %d", len(newModel.GetSuggestions()))
	}

	// Verify original model is unchanged (immutable pattern)
	if len(model.GetSuggestions()) != 0 {
		t.Errorf("original model should be unchanged, got %d suggestions", len(model.GetSuggestions()))
	}
}

// TestShowSuggestionsReturnsModel verifies that ShowSuggestions returns updated model
func TestShowSuggestionsReturnsModel(t *testing.T) {
	model := New(".")

	newModel := model.ShowSuggestions()

	// Verify active panel is set to workspace (split view)
	if newModel.activePanel != "workspace" {
		t.Errorf("expected activePanel to be 'workspace', got '%s'", newModel.activePanel)
	}

	// Verify original model is unchanged
	if model.activePanel != "workspace" {
		t.Errorf("original model should be unchanged, got activePanel '%s'", model.activePanel)
	}
}

// TestHideSuggestionsReturnsModel verifies that HideSuggestions returns updated model
func TestHideSuggestionsReturnsModel(t *testing.T) {
	model := New(".")

	newModel := model.HideSuggestions()

	// Verify active panel is set to workspace
	if newModel.activePanel != "workspace" {
		t.Errorf("expected activePanel to be 'workspace', got '%s'", newModel.activePanel)
	}

	// Verify original model is unchanged
	if model.activePanel != "workspace" {
		t.Errorf("original model should be unchanged, got activePanel '%s'", model.activePanel)
	}
}

// TestInitReturnsNilCommand verifies that Init returns nil command
func TestInitReturnsNilCommand(t *testing.T) {
	model := New(".")

	cmd := model.Init()

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected nil command from Init, got %v", cmd)
	}
}

// TestUpdateReturnsModel verifies that Update returns updated model
func TestUpdateReturnsModel(t *testing.T) {
	model := New(".")

	// Send a message that changes state
	newModel, _ := model.Update(tea.KeyMsg{Type: tea.KeyCtrlP})

	// Type assert to app.Model to access fields
	appModel, ok := newModel.(Model)
	if !ok {
		t.Fatal("failed to type assert to app.Model")
	}

	// Verify model is returned
	if appModel.activePanel != "palette" {
		t.Errorf("expected activePanel to be 'palette', got '%s'", appModel.activePanel)
	}

	// Verify original model is unchanged
	if model.activePanel != "workspace" {
		t.Errorf("original model should be unchanged, got activePanel '%s'", model.activePanel)
	}
}

// TestMessageCoverage verifies that all message types are handled correctly
func TestMessageCoverage(t *testing.T) {
	lib := &library.Library{Prompts: make(map[string]*prompt.Prompt)}
	registry := commands.NewRegistry()

	tmpDir := t.TempDir()
	dbPath := tmpDir + "/test.db"
	db, err := history.Initialize(dbPath, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create database: %v", err)
	}
	defer db.Close()

	storage, err := history.NewStorage(tmpDir, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create storage: %v", err)
	}

	historyMgr := history.NewManager(db, storage, zap.NewNop())

	aiClient, err := ai.NewClient(ai.Config{
		APIKey: "test-key",
		Model:  "claude-3-sonnet-20240229",
		Logger: zap.NewNop(),
	})
	if err != nil {
		t.Fatalf("failed to create AI client: %v", err)
	}

	contextSelector := ai.NewContextSelector()

	model := NewWithDependencies(".", lib, registry, historyMgr, false, aiClient, contextSelector)

	tests := []struct {
		name    string
		msg     tea.Msg
		wantCmd bool
	}{
		// Window size messages
		{"window resize", tea.WindowSizeMsg{Width: 100, Height: 30}, false},

		// Key messages - global bindings
		{"ctrl+c", tea.KeyMsg{Type: tea.KeyCtrlC}, true},
		{"ctrl+p", tea.KeyMsg{Type: tea.KeyCtrlP}, false},
		{"ctrl+b", tea.KeyMsg{Type: tea.KeyCtrlB}, false},
		{"ctrl+h", tea.KeyMsg{Type: tea.KeyCtrlH}, false},

		// Key messages - fall through to workspace
		{"key enter", tea.KeyMsg{Type: tea.KeyEnter}, false},
		{"key escape", tea.KeyMsg{Type: tea.KeyEsc}, false},
		{"key space", tea.KeyMsg{Type: tea.KeySpace}, false},
		{"key runes", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}}, false},

		// Diff viewer messages
		{"show diff", diffviewer.ShowDiffMsg{
			Diff:     &ai.UnifiedDiff{Header: "--- original\n+++ new"},
			Original: "original content",
			Edits:    []ai.Edit{{Line: 1, Column: 1, OldContent: "old", NewContent: "new", Length: 3}},
		}, false},
		{"hide diff", diffviewer.HideDiffMsg{}, false},
		{"accept diff", diffviewer.AcceptDiffMsg{}, false},
		{"reject diff", diffviewer.RejectDiffMsg{}, false},

		// Browser messages
		{"insert prompt", browser.InsertPromptMsg{
			FilePath:   "test.md",
			InsertMode: browser.InsertAtCursor,
		}, false},
		{"validation error", browser.ValidationErrorMsg{
			FilePath: "test.md",
			Errors:   []prompt.ValidationError{{Message: "test error"}},
		}, false},

		// History messages
		{"load history", LoadHistoryMsg{FilePath: "test.md"}, false},
		{"delete history", DeleteHistoryMsg{FilePath: "test.md"}, false},

		// Palette messages
		{"palette execute success", palette.ExecuteSuccessMsg{
			CommandID: "ai-suggestions",
		}, true},
		{"palette execute error", palette.ExecuteErrorMsg{
			CommandID: "test-command",
			Error:     errors.New("test error"),
		}, false},

		// AI suggestion messages
		{"trigger AI suggestions", TriggerAISuggestionsMsg{}, true},
		{"AI suggestions generated", AISuggestionsGeneratedMsg{
			Suggestions: []ai.Suggestion{{Title: "test"}},
		}, false},
		{"AI suggestions error", AISuggestionsErrorMsg{
			Error: errors.New("test error"),
		}, false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, cmd := model.Update(tt.msg)

			if tt.wantCmd && cmd == nil {
				t.Errorf("expected command for %s", tt.name)
			}
			if !tt.wantCmd && cmd != nil {
				t.Errorf("expected no command for %s, got %v", tt.name, cmd)
			}
		})
	}
}

// TestWindowSizeMessage verifies window size message handling
func TestWindowSizeMessage(t *testing.T) {
	model := New(".")

	// Send window size message
	newModel, cmd := model.Update(tea.WindowSizeMsg{Width: 100, Height: 30})

	// Verify no command is returned
	if cmd != nil {
		t.Errorf("expected nil command for WindowSizeMsg, got %v", cmd)
	}

	// Verify model is updated
	appModel := newModel.(Model)
	if appModel.width != 100 {
		t.Errorf("expected width 100, got %d", appModel.width)
	}
	if appModel.height != 30 {
		t.Errorf("expected height 30, got %d", appModel.height)
	}
}

// TestGlobalKeyBindings verifies global key bindings
func TestGlobalKeyBindings(t *testing.T) {
	tests := []struct {
		name      string
		key       tea.KeyType
		wantCmd   bool
		wantPanel string
	}{
		{"ctrl+c quits", tea.KeyCtrlC, true, "workspace"},
		{"ctrl+p shows palette", tea.KeyCtrlP, false, "palette"},
		{"ctrl+b shows browser", tea.KeyCtrlB, false, "browser"},
		{"ctrl+h shows history", tea.KeyCtrlH, false, "history"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			model := New(".")
			newModel, cmd := model.Update(tea.KeyMsg{Type: tt.key})

			if tt.wantCmd && cmd == nil {
				t.Errorf("expected command for %s", tt.name)
			}
			if !tt.wantCmd && cmd != nil {
				t.Errorf("expected no command for %s, got %v", tt.name, cmd)
			}

			appModel := newModel.(Model)
			if appModel.activePanel != tt.wantPanel {
				t.Errorf("expected activePanel '%s', got '%s'", tt.wantPanel, appModel.activePanel)
			}
		})
	}
}

// TestDiffViewerMessages verifies diff viewer message handling
func TestDiffViewerMessages(t *testing.T) {
	model := New(".")

	// Create a simple diff
	diff := &ai.UnifiedDiff{
		Header: "--- original\n+++ new",
		Hunks:  []ai.DiffHunk{},
	}

	// Test show diff
	newModel, cmd := model.Update(diffviewer.ShowDiffMsg{
		Diff:     diff,
		Original: "original content",
		Edits:    []ai.Edit{{Line: 1, Column: 1, OldContent: "old", NewContent: "new", Length: 3}},
	})

	if cmd != nil {
		t.Errorf("expected nil command for ShowDiffMsg, got %v", cmd)
	}

	appModel := newModel.(Model)
	if appModel.activePanel != "diffviewer" {
		t.Errorf("expected activePanel 'diffviewer', got '%s'", appModel.activePanel)
	}

	// Test hide diff
	newModel, cmd = model.Update(diffviewer.HideDiffMsg{})

	if cmd != nil {
		t.Errorf("expected nil command for HideDiffMsg, got %v", cmd)
	}

	appModel = newModel.(Model)
	if appModel.activePanel != "workspace" {
		t.Errorf("expected activePanel 'workspace', got '%s'", appModel.activePanel)
	}
}

// TestBrowserMessages verifies browser message handling
func TestBrowserMessages(t *testing.T) {
	lib := &library.Library{Prompts: make(map[string]*prompt.Prompt)}
	registry := commands.NewRegistry()
	model := NewWithDependencies(".", lib, registry, nil, false, nil, nil)

	// Test insert prompt message
	newModel, cmd := model.Update(browser.InsertPromptMsg{
		FilePath:   "test.md",
		InsertMode: browser.InsertAtCursor,
	})

	if cmd != nil {
		t.Errorf("expected nil command for InsertPromptMsg, got %v", cmd)
	}

	appModel := newModel.(Model)
	if appModel.activePanel != "workspace" {
		t.Errorf("expected activePanel 'workspace', got '%s'", appModel.activePanel)
	}

	// Test validation error message
	newModel, cmd = model.Update(browser.ValidationErrorMsg{
		FilePath: "test.md",
		Errors:   []prompt.ValidationError{{Message: "test error"}},
	})

	if cmd != nil {
		t.Errorf("expected nil command for ValidationErrorMsg, got %v", cmd)
	}

	appModel = newModel.(Model)
	if appModel.activePanel != "workspace" {
		t.Errorf("expected activePanel 'workspace', got '%s'", appModel.activePanel)
	}
}

// TestHistoryMessages verifies history message handling
func TestHistoryMessages(t *testing.T) {
	tmpDir := t.TempDir()
	dbPath := tmpDir + "/test.db"
	db, err := history.Initialize(dbPath, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create database: %v", err)
	}
	defer db.Close()

	storage, err := history.NewStorage(tmpDir, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create storage: %v", err)
	}

	historyMgr := history.NewManager(db, storage, zap.NewNop())
	lib := &library.Library{Prompts: make(map[string]*prompt.Prompt)}
	registry := commands.NewRegistry()
	model := NewWithDependencies(".", lib, registry, historyMgr, false, nil, nil)

	// Test load history message
	newModel, cmd := model.Update(LoadHistoryMsg{FilePath: "test.md"})

	if cmd != nil {
		t.Errorf("expected nil command for LoadHistoryMsg, got %v", cmd)
	}

	appModel := newModel.(Model)
	if appModel.activePanel != "workspace" {
		t.Errorf("expected activePanel 'workspace', got '%s'", appModel.activePanel)
	}

	// Test delete history message
	newModel, cmd = model.Update(DeleteHistoryMsg{FilePath: "test.md"})

	if cmd != nil {
		t.Errorf("expected nil command for DeleteHistoryMsg, got %v", cmd)
	}

	appModel = newModel.(Model)
	if appModel.activePanel != "workspace" {
		t.Errorf("expected activePanel 'workspace', got '%s'", appModel.activePanel)
	}
}

// TestPaletteMessages verifies palette message handling
func TestPaletteMessages(t *testing.T) {
	model := New(".")

	// Test palette execute success message
	newModel, cmd := model.Update(palette.ExecuteSuccessMsg{
		CommandID: "ai-suggestions",
	})

	if cmd == nil {
		t.Fatal("expected command for ExecuteSuccessMsg with ai-suggestions")
	}

	// Verify command returns TriggerAISuggestionsMsg
	msg := cmd()
	if _, ok := msg.(TriggerAISuggestionsMsg); !ok {
		t.Errorf("expected TriggerAISuggestionsMsg, got %v", msg)
	}

	// Test palette execute error message
	newModel, cmd = model.Update(palette.ExecuteErrorMsg{
		CommandID: "test-command",
		Error:     errors.New("test error"),
	})

	if cmd != nil {
		t.Errorf("expected nil command for ExecuteErrorMsg, got %v", cmd)
	}

	appModel := newModel.(Model)
	// Verify status message is set (can't directly access, just verify no crash)
	_ = appModel
}

// TestAISuggestionMessages verifies AI suggestion message handling
func TestAISuggestionMessages(t *testing.T) {
	lib := &library.Library{Prompts: make(map[string]*prompt.Prompt)}
	registry := commands.NewRegistry()

	tmpDir := t.TempDir()
	dbPath := tmpDir + "/test.db"
	db, err := history.Initialize(dbPath, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create database: %v", err)
	}
	defer db.Close()

	storage, err := history.NewStorage(tmpDir, zap.NewNop())
	if err != nil {
		t.Fatalf("failed to create storage: %v", err)
	}

	historyMgr := history.NewManager(db, storage, zap.NewNop())

	aiClient, err := ai.NewClient(ai.Config{
		APIKey: "test-key",
		Model:  "claude-3-sonnet-20240229",
		Logger: zap.NewNop(),
	})
	if err != nil {
		t.Fatalf("failed to create AI client: %v", err)
	}

	contextSelector := ai.NewContextSelector()

	model := NewWithDependencies(".", lib, registry, historyMgr, false, aiClient, contextSelector)

	// Test trigger AI suggestions message
	newModel, cmd := model.Update(TriggerAISuggestionsMsg{})

	if cmd == nil {
		t.Fatal("expected command for TriggerAISuggestionsMsg")
	}

	// Test AI suggestions generated message
	newModel, cmd = model.Update(AISuggestionsGeneratedMsg{
		Suggestions: []ai.Suggestion{{Title: "test"}},
	})

	if cmd != nil {
		t.Errorf("expected nil command for AISuggestionsGeneratedMsg, got %v", cmd)
	}

	// Update model reference to the returned model
	model = newModel.(Model)

	if len(model.GetSuggestions()) != 1 {
		t.Errorf("expected 1 suggestion, got %d", len(model.GetSuggestions()))
	}

	// Test AI suggestions error message
	newModel, cmd = model.Update(AISuggestionsErrorMsg{
		Error: errors.New("test error"),
	})

	if cmd != nil {
		t.Errorf("expected nil command for AISuggestionsErrorMsg, got %v", cmd)
	}
}

// TestFallthroughKeyMessages verifies that non-global keys fall through to workspace
func TestFallthroughKeyMessages(t *testing.T) {
	model := New(".")

	tests := []struct {
		name string
		key  tea.KeyType
	}{
		{"enter falls through", tea.KeyEnter},
		{"escape falls through", tea.KeyEsc},
		{"space falls through", tea.KeySpace},
		{"runes fall through", tea.KeyRunes},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			newModel, cmd := model.Update(tea.KeyMsg{Type: tt.key})

			// Verify no command is returned (falls through to workspace)
			if cmd != nil {
				t.Errorf("expected no command for %s, got %v", tt.name, cmd)
			}

			// Verify model is returned
			appModel := newModel.(Model)
			_ = appModel
		})
	}
}

// TestActivePanelSwitching verifies that active panel switching works correctly
func TestActivePanelSwitching(t *testing.T) {
	model := New(".")

	// Start with workspace
	if model.activePanel != "workspace" {
		t.Errorf("expected initial activePanel 'workspace', got '%s'", model.activePanel)
	}

	// Switch to palette
	newModel, _ := model.Update(tea.KeyMsg{Type: tea.KeyCtrlP})
	appModel := newModel.(Model)
	if appModel.activePanel != "palette" {
		t.Errorf("expected activePanel 'palette', got '%s'", appModel.activePanel)
	}

	// Switch to browser
	newModel, _ = model.Update(tea.KeyMsg{Type: tea.KeyCtrlB})
	appModel = newModel.(Model)
	if appModel.activePanel != "browser" {
		t.Errorf("expected activePanel 'browser', got '%s'", appModel.activePanel)
	}

	// Switch to history
	newModel, _ = model.Update(tea.KeyMsg{Type: tea.KeyCtrlH})
	appModel = newModel.(Model)
	if appModel.activePanel != "history" {
		t.Errorf("expected activePanel 'history', got '%s'", appModel.activePanel)
	}
}

// TestModelImmutability verifies that Update returns new model instances
func TestModelImmutability(t *testing.T) {
	model := New(".")

	// Send a message that changes state
	newModel, _ := model.Update(tea.KeyMsg{Type: tea.KeyCtrlP})

	// Verify original model is unchanged
	if model.activePanel != "workspace" {
		t.Errorf("original model should be unchanged, got activePanel '%s'", model.activePanel)
	}

	// Verify new model is updated
	appModel := newModel.(Model)
	if appModel.activePanel != "palette" {
		t.Errorf("new model should have activePanel 'palette', got '%s'", appModel.activePanel)
	}
}
