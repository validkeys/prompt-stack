package palette

import (
	"errors"
	"testing"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/kyledavis/prompt-stack/internal/commands"
)

// TestNew verifies that New creates a properly initialized model
func TestNew(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)

	// Verify initial state
	if model.registry == nil {
		t.Error("expected registry to be initialized")
	}
	if len(model.filtered) == 0 {
		t.Error("expected filtered commands to be initialized")
	}
	if model.selected != 0 {
		t.Errorf("expected selected 0, got %d", model.selected)
	}
	if model.searchInput != "" {
		t.Errorf("expected empty search input, got '%s'", model.searchInput)
	}
	if model.visible {
		t.Error("expected visible to be false")
	}
	if model.vimMode {
		t.Error("expected vimMode to be false")
	}
}

// TestNewWithVimMode verifies that New respects vim mode setting
func TestNewWithVimMode(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, true)

	if !model.vimMode {
		t.Error("expected vimMode to be true")
	}
}

// TestInit verifies that Init returns nil command
func TestInit(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)

	cmd := model.Init()

	if cmd != nil {
		t.Errorf("expected nil command from Init, got %v", cmd)
	}
}

// TestUpdateKeyEsc verifies that Escape key hides palette
func TestUpdateKeyEsc(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()

	// Verify visible
	if !model.visible {
		t.Error("expected palette to be visible")
	}

	// Send Escape key
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyEsc})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify hidden
	if paletteModel.visible {
		t.Error("expected palette to be hidden after Escape")
	}
}

// TestUpdateKeyEnter verifies that Enter key executes command
func TestUpdateKeyEnter(t *testing.T) {
	registry := commands.NewRegistry()

	// Register a test command
	executed := false
	testCmd := &commands.Command{
		ID:   "test-cmd",
		Name: "Test Command",
		Handler: func() error {
			executed = true
			return nil
		},
	}
	registry.Register(testCmd)

	model := New(registry, false)
	model = model.Show()

	// Send Enter key
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyEnter})

	// Verify command is returned
	if cmd == nil {
		t.Fatal("expected command from Enter")
	}

	// Execute command
	msg := cmd()
	if _, ok := msg.(ExecuteSuccessMsg); !ok {
		t.Errorf("expected ExecuteSuccessMsg, got %v", msg)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify palette is hidden
	if paletteModel.visible {
		t.Error("expected palette to be hidden after Enter")
	}

	// Verify command was executed
	if !executed {
		t.Error("expected command handler to be executed")
	}
}

// TestUpdateKeyEnterWithNoCommands verifies that Enter with no commands does nothing
func TestUpdateKeyEnterWithNoCommands(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()

	// Clear filtered commands
	model.filtered = []*commands.Command{}

	// Send Enter key
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyEnter})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify model unchanged
	if paletteModel.visible != model.visible {
		t.Error("expected model to be unchanged")
	}
}

// TestUpdateKeyUp verifies that Up key moves selection up
func TestUpdateKeyUp(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Command 2"}
	cmd3 := &commands.Command{ID: "cmd3", Name: "Command 3"}
	registry.Register(cmd1)
	registry.Register(cmd2)
	registry.Register(cmd3)

	model := New(registry, false)
	model = model.Show()

	// Move to second item
	model.selected = 1

	// Send Up key
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyUp})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify selection moved up
	if paletteModel.selected != 0 {
		t.Errorf("expected selected 0, got %d", paletteModel.selected)
	}
}

// TestUpdateKeyDown verifies that Down key moves selection down
func TestUpdateKeyDown(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Command 2"}
	cmd3 := &commands.Command{ID: "cmd3", Name: "Command 3"}
	registry.Register(cmd1)
	registry.Register(cmd2)
	registry.Register(cmd3)

	model := New(registry, false)
	model = model.Show()

	// Send Down key
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyDown})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify selection moved down
	if paletteModel.selected != 1 {
		t.Errorf("expected selected 1, got %d", paletteModel.selected)
	}
}

// TestUpdateKeyBackspace verifies that Backspace deletes from search input
func TestUpdateKeyBackspace(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()
	model.searchInput = "test"

	// Send Backspace key
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyBackspace})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify character deleted
	if paletteModel.searchInput != "tes" {
		t.Errorf("expected 'tes', got '%s'", paletteModel.searchInput)
	}
}

// TestUpdateKeyBackspaceEmpty verifies that Backspace on empty input does nothing
func TestUpdateKeyBackspaceEmpty(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()

	// Send Backspace key on empty input
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyBackspace})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify input still empty
	if paletteModel.searchInput != "" {
		t.Errorf("expected empty input, got '%s'", paletteModel.searchInput)
	}
}

// TestUpdateKeyRunes verifies that typing adds to search input
func TestUpdateKeyRunes(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()

	// Type characters
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'t', 'e', 's', 't'}})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify characters added
	if paletteModel.searchInput != "test" {
		t.Errorf("expected 'test', got '%s'", paletteModel.searchInput)
	}
}

// TestUpdateVimMode verifies that vim mode keybindings work
func TestUpdateVimMode(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Command 2"}
	cmd3 := &commands.Command{ID: "cmd3", Name: "Command 3"}
	registry.Register(cmd1)
	registry.Register(cmd2)
	registry.Register(cmd3)

	model := New(registry, true)
	model = model.Show()

	// Test 'j' for down
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'j'}})
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}
	paletteModel := newModel.(Model)
	if paletteModel.selected != 1 {
		t.Errorf("expected selected 1 after 'j', got %d", paletteModel.selected)
	}

	// Test 'k' for up
	newModel, cmd = newModel.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'k'}})
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}
	paletteModel = newModel.(Model)
	if paletteModel.selected != 0 {
		t.Errorf("expected selected 0 after 'k', got %d", paletteModel.selected)
	}
}

// TestUpdateWindowSize verifies that window resize is handled
func TestUpdateWindowSize(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)

	// Send window size message
	newModel, cmd := model.Update(tea.WindowSizeMsg{Width: 100, Height: 30})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify dimensions updated
	if paletteModel.width != 100 {
		t.Errorf("expected width 100, got %d", paletteModel.width)
	}
	if paletteModel.height != 30 {
		t.Errorf("expected height 30, got %d", paletteModel.height)
	}
}

// TestViewHidden verifies that View returns empty string when hidden
func TestViewHidden(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)

	view := model.View()

	if view != "" {
		t.Errorf("expected empty view when hidden, got '%s'", view)
	}
}

// TestViewVisible verifies that View renders when visible
func TestViewVisible(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()
	newModel, _ := model.Update(tea.WindowSizeMsg{Width: 80, Height: 24})
	model = newModel.(Model)

	view := model.View()

	if view == "" {
		t.Error("expected non-empty view when visible")
	}

	// Should contain header
	if len(view) == 0 {
		t.Error("expected view to have content")
	}
}

// TestViewSmallTerminal verifies that View handles small terminals
func TestViewSmallTerminal(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()
	newModel, _ := model.Update(tea.WindowSizeMsg{Width: 5, Height: 5})
	model = newModel.(Model)

	view := model.View()

	// Should not crash
	if view == "" {
		t.Error("expected view to render even on small terminal")
	}
}

// TestShow verifies that Show makes palette visible
func TestShow(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)

	// Verify initially hidden
	if model.visible {
		t.Error("expected palette to be hidden initially")
	}

	// Show palette
	newModel := model.Show()

	// Verify visible
	if !newModel.visible {
		t.Error("expected palette to be visible after Show")
	}

	// Verify search input cleared
	if newModel.searchInput != "" {
		t.Errorf("expected empty search input, got '%s'", newModel.searchInput)
	}

	// Verify filter applied
	if len(newModel.filtered) == 0 {
		t.Error("expected filtered commands to be populated")
	}
}

// TestHide verifies that Hide makes palette invisible
func TestHide(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()

	// Verify visible
	if !model.visible {
		t.Error("expected palette to be visible")
	}

	// Hide palette
	newModel := model.Hide()

	// Verify hidden
	if newModel.visible {
		t.Error("expected palette to be hidden after Hide")
	}
}

// TestIsVisible verifies that IsVisible returns correct state
func TestIsVisible(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)

	// Initially hidden
	if model.IsVisible() {
		t.Error("expected IsVisible to return false initially")
	}

	// Show palette
	model = model.Show()

	// Now visible
	if !model.IsVisible() {
		t.Error("expected IsVisible to return true after Show")
	}
}

// TestMoveSelection verifies that moveSelection handles boundaries
func TestMoveSelection(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Command 2"}
	cmd3 := &commands.Command{ID: "cmd3", Name: "Command 3"}
	registry.Register(cmd1)
	registry.Register(cmd2)
	registry.Register(cmd3)

	model := New(registry, false)
	model = model.Show()

	// Test moving up from first item (should stay at 0)
	model.selected = 0
	newModel := model.moveSelection(-1)
	if newModel.selected != 0 {
		t.Errorf("expected selection to stay at 0, got %d", newModel.selected)
	}

	// Test moving down from last item (should stay at last)
	model.selected = 2
	newModel = model.moveSelection(1)
	if newModel.selected != 2 {
		t.Errorf("expected selection to stay at 2, got %d", newModel.selected)
	}

	// Test normal movement
	model.selected = 1
	newModel = model.moveSelection(1)
	if newModel.selected != 2 {
		t.Errorf("expected selection to move to 2, got %d", newModel.selected)
	}
}

// TestApplyFilter verifies that applyFilter filters commands
func TestApplyFilter(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Test Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Another Command"}
	cmd3 := &commands.Command{ID: "cmd3", Name: "Test Command 2"}
	registry.Register(cmd1)
	registry.Register(cmd2)
	registry.Register(cmd3)

	model := New(registry, false)
	model = model.Show()

	// Apply filter
	model.searchInput = "Test"
	newModel := model.applyFilter()

	// Verify filtered results
	if len(newModel.filtered) != 2 {
		t.Errorf("expected 2 filtered commands, got %d", len(newModel.filtered))
	}

	// Verify selection reset
	if newModel.selected != 0 {
		t.Errorf("expected selection reset to 0, got %d", newModel.selected)
	}
}

// TestApplyFilterEmpty verifies that empty filter shows all commands
func TestApplyFilterEmpty(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Command 2"}
	registry.Register(cmd1)
	registry.Register(cmd2)

	model := New(registry, false)
	model = model.Show()

	// Apply empty filter
	model.searchInput = ""
	newModel := model.applyFilter()

	// Verify all commands shown
	if len(newModel.filtered) != 2 {
		t.Errorf("expected 2 filtered commands, got %d", len(newModel.filtered))
	}
}

// TestSetSize verifies that SetSize updates dimensions
func TestSetSize(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)

	newModel, _ := model.Update(tea.WindowSizeMsg{Width: 100, Height: 30})
	model = newModel.(Model)

	if model.width != 100 {
		t.Errorf("expected width 100, got %d", model.width)
	}
	if model.height != 30 {
		t.Errorf("expected height 30, got %d", model.height)
	}
}

// TestMessageCoverage verifies that all message types are handled
func TestMessageCoverage(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()

	tests := []struct {
		name    string
		msg     tea.Msg
		wantCmd bool
	}{
		{"window resize", tea.WindowSizeMsg{Width: 80, Height: 24}, false},
		{"key escape", tea.KeyMsg{Type: tea.KeyEsc}, false},
		{"key enter", tea.KeyMsg{Type: tea.KeyEnter}, true},
		{"key up", tea.KeyMsg{Type: tea.KeyUp}, false},
		{"key down", tea.KeyMsg{Type: tea.KeyDown}, false},
		{"key backspace", tea.KeyMsg{Type: tea.KeyBackspace}, false},
		{"key runes", tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}}, false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, cmd := model.Update(tt.msg)

			if tt.wantCmd && cmd == nil {
				t.Errorf("expected command for %s", tt.name)
			}
			if !tt.wantCmd && cmd != nil {
				t.Errorf("expected no command for %s, got %v", tt.name, cmd)
			}
		})
	}
}

// TestExecuteSuccessMsg verifies that ExecuteSuccessMsg is handled
func TestExecuteSuccessMsg(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()

	// Send ExecuteSuccessMsg
	newModel, cmd := model.Update(ExecuteSuccessMsg{CommandID: "test-cmd"})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify model unchanged (command not found)
	if paletteModel.visible != model.visible {
		t.Error("expected model to be unchanged")
	}
}

// TestExecuteErrorMsg verifies that ExecuteErrorMsg is handled
func TestExecuteErrorMsg(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()

	// Send ExecuteErrorMsg
	newModel, cmd := model.Update(ExecuteErrorMsg{
		CommandID: "test-cmd",
		Error:     errors.New("test error"),
	})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify model unchanged
	if paletteModel.visible != model.visible {
		t.Error("expected model to be unchanged")
	}
}

// TestMinHelper verifies that min helper works correctly
func TestMinHelper(t *testing.T) {
	tests := []struct {
		a, b, want int
	}{
		{1, 2, 1},
		{2, 1, 1},
		{1, 1, 1},
		{0, 10, 0},
		{-1, 1, -1},
	}

	for _, tt := range tests {
		t.Run("", func(t *testing.T) {
			result := min(tt.a, tt.b)
			if result != tt.want {
				t.Errorf("min(%d, %d) = %d, want %d", tt.a, tt.b, result, tt.want)
			}
		})
	}
}

// TestMaxHelper verifies that max helper works correctly
func TestMaxHelper(t *testing.T) {
	tests := []struct {
		a, b, want int
	}{
		{1, 2, 2},
		{2, 1, 2},
		{1, 1, 1},
		{0, 10, 10},
		{-1, 1, 1},
	}

	for _, tt := range tests {
		t.Run("", func(t *testing.T) {
			result := max(tt.a, tt.b)
			if result != tt.want {
				t.Errorf("max(%d, %d) = %d, want %d", tt.a, tt.b, result, tt.want)
			}
		})
	}
}

// TestFilterWithNoMatches verifies that filter with no matches shows empty list
func TestFilterWithNoMatches(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Command 2"}
	registry.Register(cmd1)
	registry.Register(cmd2)

	model := New(registry, false)
	model = model.Show()

	// Apply filter with no matches
	model.searchInput = "nonexistent"
	newModel := model.applyFilter()

	// Verify no results
	if len(newModel.filtered) != 0 {
		t.Errorf("expected 0 filtered commands, got %d", len(newModel.filtered))
	}

	// Verify selection reset
	if newModel.selected != 0 {
		t.Errorf("expected selection reset to 0, got %d", newModel.selected)
	}
}

// TestNavigationWithEmptyList verifies that navigation works with empty list
func TestNavigationWithEmptyList(t *testing.T) {
	registry := commands.NewRegistry()
	model := New(registry, false)
	model = model.Show()
	model.filtered = []*commands.Command{}

	// Try to navigate
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyUp})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify selection stays at 0
	if paletteModel.selected != 0 {
		t.Errorf("expected selection to stay at 0, got %d", paletteModel.selected)
	}
}

// TestTypingAfterFilter verifies that typing updates filter
func TestTypingAfterFilter(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Test Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Another Command"}
	registry.Register(cmd1)
	registry.Register(cmd2)

	model := New(registry, false)
	model = model.Show()

	// Type "Test"
	newModel, _ := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'T', 'e', 's', 't'}})

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify search input updated
	if paletteModel.searchInput != "Test" {
		t.Errorf("expected 'Test', got '%s'", paletteModel.searchInput)
	}

	// Verify filter applied
	if len(paletteModel.filtered) != 1 {
		t.Errorf("expected 1 filtered command, got %d", len(paletteModel.filtered))
	}
}

// TestBackspaceAfterFilter verifies that backspace updates filter
func TestBackspaceAfterFilter(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Test Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Another Command"}
	registry.Register(cmd1)
	registry.Register(cmd2)

	model := New(registry, false)
	model = model.Show()
	model.searchInput = "Test"

	// Backspace
	newModel, _ := model.Update(tea.KeyMsg{Type: tea.KeyBackspace})

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify search input updated
	if paletteModel.searchInput != "Tes" {
		t.Errorf("expected 'Tes', got '%s'", paletteModel.searchInput)
	}

	// Verify filter updated
	if len(paletteModel.filtered) != 1 {
		t.Errorf("expected 1 filtered command, got %d", len(paletteModel.filtered))
	}
}

// TestEnterWithCommandError verifies that Enter with command error returns error message
func TestEnterWithCommandError(t *testing.T) {
	registry := commands.NewRegistry()

	// Register a command that returns an error
	errorCmd := &commands.Command{
		ID:   "error-cmd",
		Name: "Error Command",
		Handler: func() error {
			return errors.New("command failed")
		},
	}
	registry.Register(errorCmd)

	model := New(registry, false)
	model = model.Show()

	// Send Enter key
	_, cmd := model.Update(tea.KeyMsg{Type: tea.KeyEnter})

	// Verify command is returned
	if cmd == nil {
		t.Fatal("expected command from Enter")
	}

	// Execute command
	msg := cmd()
	if errorMsg, ok := msg.(ExecuteErrorMsg); !ok {
		t.Errorf("expected ExecuteErrorMsg, got %v", msg)
	} else if errorMsg.Error == nil {
		t.Error("expected error to be set")
	}
}

// TestVimModeDisabled verifies that vim mode keybindings don't work when disabled
func TestVimModeDisabled(t *testing.T) {
	registry := commands.NewRegistry()

	// Register test commands
	cmd1 := &commands.Command{ID: "cmd1", Name: "Command 1"}
	cmd2 := &commands.Command{ID: "cmd2", Name: "Command 2"}
	registry.Register(cmd1)
	registry.Register(cmd2)

	model := New(registry, false)
	model = model.Show()

	// Try 'j' key (should not move selection in non-vim mode)
	newModel, cmd := model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'j'}})

	// Verify no command
	if cmd != nil {
		t.Errorf("expected nil command, got %v", cmd)
	}

	// Type assert to access fields
	paletteModel := newModel.(Model)

	// Verify selection unchanged
	if paletteModel.selected != 0 {
		t.Errorf("expected selection to stay at 0, got %d", paletteModel.selected)
	}
}
